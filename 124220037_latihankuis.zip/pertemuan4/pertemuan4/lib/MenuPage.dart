import 'package:flutter/material.dart';
import 'dummy_menu.dart'; // Mengimpor data dari dummy_menu.dart

class MenuPage extends StatelessWidget {
  // Inisiasi variabel
  final String username;
  final String? nickname;

  MenuPage({Key? key, required this.username, this.nickname});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Halaman Home"),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Text("Selamat datang! $username"),
                if (nickname != null) Text('Panggilan Saya $nickname'),
                Text("Ini adalah halaman home."),
                SizedBox(height: 24),
                ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.red),
                    foregroundColor: MaterialStateProperty.all(Colors.white),
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Logout'),
                ),
              ],
            ),
          ),
          Expanded(child: FoodMenuList()), // Menggunakan FoodMenuList untuk menampilkan data dari dummy_menu.dart
        ],
      ),
    );
  }
}

// Widget untuk menampilkan daftar menu makanan
class FoodMenuList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: foodMenuList.length, // Mengambil jumlah item dari dummy_menu.dart
      itemBuilder: (context, index) {
        final food = foodMenuList[index]; // Mendapatkan data setiap item
        return Card(
          child: ListTile(
            leading: Image.asset(
              food.imageAsset, // Menampilkan gambar dari dummy_menu.dart
              width: 50,
              height: 50,
              fit: BoxFit.cover,
            ),
            title: Text(food.name), // Nama makanan
            subtitle: Text('${food.category} - ${food.price}'), // Kategori dan harga
            onTap: () {
              // Aksi saat item diklik, seperti menampilkan detail makanan
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text(food.name),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Deskripsi: ${food.description}'),
                      Text('Bahan: ${food.ingredients}'),
                      Text('Waktu Masak: ${food.cookingTime}'),
                      Text('Harga: ${food.price}'),
                    ],
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('Tutup'),
                    ),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }
}
