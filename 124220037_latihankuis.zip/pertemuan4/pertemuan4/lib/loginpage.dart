import 'package:flutter/material.dart';
import 'MenuPage.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String _username = '';
  String? _nickname;
  String _password = '';
  bool isClicked = false;

  // function
  _navigateToHome() async{
    await Future.delayed(Duration(seconds: 3), () {});
    Navigator.push(
      context, 
      MaterialPageRoute
      (builder: (context) => MenuPage(
        username: _username, 
        nickname: _nickname,
      )));
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: Text("Login Page"),
        ),
        body: Column(
          children: [
            _usernameField(),
            _passwordField(),
            TextFormField(
              enabled: true,
              onChanged: (value) {
                _nickname = value;
              },
              decoration: InputDecoration(
                hintText: 'Masukkan Panggilan',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(12)),
                  borderSide: BorderSide(
                    width: 70000, color: Colors.blue
                  )
                )
              ),
              ),
            _loginButton(),
          ],
        ),
      ),
    );
  }

  Widget _usernameField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: TextFormField(
        enabled: true,
        onChanged: (value) {
          setState(() {
            _username = value;
          });
        },
        decoration: InputDecoration(
          hintText: 'Masukkan username',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(12)),
          ),
        ),
      ),
    );
  }

  Widget _passwordField() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: TextFormField(
        enabled: true,
        obscureText: true, // Menambahkan obscureText untuk input password
        onChanged: (value) {
          setState(() {
            _password = value;
          });
        },
        decoration: InputDecoration(
          hintText: 'Masukkan password',
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(12)),
          ),
        ),
      ),
    );
  }

  Widget _loginButton() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: ElevatedButton(
        style: ButtonStyle(
          backgroundColor: WidgetStateProperty.all(Colors.blue)
        ),
        onPressed: () {
          if (_username == "mufidatulk96" && _password == "123") {
            _navigateToHome();

            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Login Berhasil'),
              ),
            );

            setState(() {
              isClicked = !isClicked;
              print(isClicked);
            });
          }
        },
        child: const Text('Login'),
      ),
    );
  }
}